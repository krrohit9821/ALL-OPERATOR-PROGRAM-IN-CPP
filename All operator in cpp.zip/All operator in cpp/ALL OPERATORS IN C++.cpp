//Write a Menu Driven Program to implement all the operators in C++.

#include<iostream>
using namespace std;

void add()
{
	int a,b;
	cout<<"\nEnter first number : ";
	cin>>a;
	cout<<"\nEnter second number : ";
	cin>>b;
	cout<<"\nAddition = "<<a+b<<endl;
}

void sub()
{
	int a,b;
	cout<<"\nEnter first number : ";
	cin>>a;
	cout<<"\nEnter second number : ";
	cin>>b;
	cout<<"\nSubtraction = "<<a-b<<endl;
}

void multi()
{
	int a,b;
	cout<<"\nEnter first number : ";
	cin>>a;
	cout<<"\nEnter second number : ";
	cin>>b;
	cout<<"\nMultiplication = "<<a*b<<endl;
}

void div()
{
	int a,b;
	cout<<"\nEnter first number : ";
	cin>>a;
	cout<<"\nEnter second number : ";
	cin>>b;
	cout<<"\nDivison = "<<a/b<<endl;
}

void mod()
{
	int a,b;
	cout<<"\nEnter first number : ";
	cin>>a;
	cout<<"\nEnter second number : ";
	cin>>b;
	cout<<"\nMod = "<<a%b<<endl;
}

void arithmetic()
{
	int ch;
	while(1)
	{
		cout<<"\n1.Addition";
		cout<<"\n2.Subtraction";
		cout<<"\n3.Multiplication";
		cout<<"\n4.Division";
		cout<<"\n5.Modulo Operation(Remainder after division)";
		cout<<"\n6.Exit";
		
		cout<<"\n\nEnter your choice : ";
		cin>>ch;
		
		switch(ch)
		{
			case 1:
				add();
				break;
			case 2:
				sub();
				break;
			case 3:
				multi();
				break;
			case 4:
				div();
				break;	
			case 5:
				mod();
				break;
			case 6:
				exit(1);
				break;
			default:
				cout<<"\nInvalid Choice! Please Enter a Valid Choice.\n";
		}
	}
}

void equal()
{
	int a,b;
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	a=b;
	cout<<"\nAfter a = b \na = "<<a<<endl;
}

void plus_equal()
{
	int a,b;
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	a+=b;//a=a+b;
	cout<<"\nAfter a += b \na = "<<a<<endl;
}

void minus_equal()
{
	int a,b;
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	a-=b;
	cout<<"\nAfter a -= b \na = "<<a<<endl;
}

void multi_equal()
{
	int a,b;
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	a*=b;
	cout<<"\nAfter a *= b \na = "<<a<<endl;
}

void div_equal()
{
	int a,b;
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	a/=b;
	cout<<"\nAfter a /= b \na = "<<a<<endl;
}

void mod_equal()
{
	int a,b;
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	a%=b;
	cout<<"\nAfter a %= b \na = "<<a<<endl;
}

void assignment()
{
	while(1)
	{
		int ch;
	
		cout<<"\n1. = ";
		cout<<"\n2. += ";
		cout<<"\n3. -= ";
		cout<<"\n4. *= ";
		cout<<"\n5. /= ";
		cout<<"\n6. %= ";
		cout<<"\n7. Exit";
		
		cout<<"\n\nEnter your choice : ";
		cin>>ch;
		
		switch (ch)
		{
			case 1:
				equal();
				break;
			case 2:
				plus_equal();
				break;
			case 3:
				minus_equal();
				break;
			case 4:
				multi_equal();
				break;
			case 5:
				div_equal();
				break;
			case 6:
				mod_equal();
				break;
			case 7:
				exit(1);
				break;
			default:
				cout<<"\n\nInvalid Choice!!! Please try again\n";		
		}
	}
}

void IsEqualTo()
{
	int a,b;
	bool result;
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	
	result = (a==b);
	cout<<a<<" == "<<b<<" is "<<result<<endl;
}

void NotEqualTo()
{
	int a,b;
	bool result;
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	
	result = (a!=b);
	cout<<a<<" != "<<b<<" is "<<result<<endl;
}

void GreaterThan()
{
	int a,b;
	bool result;
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	
	result = (a>b);
	cout<<a<<" > "<<b<<" is "<<result<<endl;
}

void LessThan()
{
	int a,b;
	bool result;
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	
	result = (a<b);
	cout<<a<<" < "<<b<<" is "<<result<<endl;
}

void Greater_Than_or_Equal_To()
{
	int a,b;
	bool result;
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	
	result = (a>=b);
	cout<<a<<" >= "<<b<<" is "<<result<<endl;
}

void Less_Than_or_Equal_To()
{
	int a,b;
	bool result;
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	
	result = (a<=b);
	cout<<a<<" <= "<<b<<" is "<<result<<endl;
}

void relational()
{
	int ch;
	while(1)
	{
		cout<<"\n1. == ";
		cout<<"\n2. != ";
		cout<<"\n3. > ";
		cout<<"\n4. < ";
		cout<<"\n5. >= ";
		cout<<"\n6. <= ";
		cout<<"\n7. Exit";
		
		cout<<"\n\nEnter your choice : ";
		cin>>ch;
		
		switch(ch)
		{
			case 1:
				IsEqualTo();
				break;
			case 2:
				NotEqualTo();
				break;
			case 3:
				GreaterThan();
				break;
			case 4:
				LessThan();
				break;
			case 5:
				Greater_Than_or_Equal_To();
				break;
			case 6:
				Less_Than_or_Equal_To();
				break;
			case 7:
				exit(1);
				break;
			default:
				cout<<"\nInvalid Choice!!! Please try again\n";
		}
	}
}

void Logical_AND()
{
	int a,b;
	bool result;
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	
	result = (a != b) && (a < b);     // true
    cout << "\n("<<a<<" != "<<b<<") && ("<<a<<" < "<<b<<") is " << result << endl;

    result = (a == b) && (a < b);    // false
    cout << "("<<a<<" == "<<b<<") && ("<<a<<" < "<<b<<") is " << result << endl;

    result = (a == b) && (a > b);    // false
    cout << "("<<a<<" == "<<b<<") && ("<<a<<" > "<<b<<") is " << result << endl;
}

void Logical_OR()
{
	int a,b;
	bool result;
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	
	result = (a != b) || (a < b);	// true
	cout<<"\n("<<a<<" != "<<b<<") || ("<<a<<" < "<<b<<") is "<<result<<endl;
	
	result = (a != b) || (a > b);	// true
	cout<<"("<<a<<" != "<<b<<") || ("<<a<<" > "<<b<<") is "<<result<<endl;
	
	result = (a == b) || (a > b);	// false
	cout<<"("<<a<<" == "<<b<<") || ("<<a<<" > "<<b<<") is "<<result<<endl;

}

void Logical_NOT()
{
	int a,b;
	bool result;
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	
	result = !(a == b);    // true
    cout << "\n!("<<a<<" == "<<b<<") is " << result << endl;

    result = !(a == a);    // false
    cout << "!("<<a<<" == "<<a<<") is " << result << endl;
}

void logical()
{
	int ch;
	while(1)
	{
		cout<<"\n1. Logical AND (&&) ";
		cout<<"\n2. Logical OR (||) ";
		cout<<"\n3. Logical NOT(!) ";
		cout<<"\n4. Exit";
		
		cout<<"\n\nEnter your choice : ";
		cin>>ch;
		
		switch(ch)
		{
			case 1:
				Logical_AND();
				break;
			case 2:
				Logical_OR();
				break;
			case 3:
				Logical_NOT();
				break;
			case 4:
				exit(1);
				break;
			default:
				cout<<"\nInvalid Choice!!! Please try again\n";
		}
	}
}

void Bitwise_AND()
{
	int a,b;
	
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	
	cout <<"\n"<<a<<" & "<<b<<" = " << (a & b) << endl;
}

void Bitwise_OR()
{
	int a,b;
	
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	
	cout <<"\n"<<a<<" | "<<b<<" = " << (a | b) << endl;
}

void Bitwise_XOR()
{
	int a,b;
	
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	
	cout <<"\n"<<a<<" ^ "<<b<<" = " << (a ^ b) << endl;
}

void Bitwise_Complement()
{
	int a,b;
	
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;
	
	cout << endl<<"~(" <<a<< ") = " << (~a) << endl;
    cout << "~(" <<b<< ") = " << (~b) << endl;
}

void Right_Shift()
{
	int a,b;
	
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;

    cout << "\nShift Right : " << endl; 
    cout << a<<" >> " << b << " = " << (a >> b) << endl;
}

void Left_Shift()
{
	int a,b;
	
	cout<<"\nEnter the value of a : ";
	cin>>a;
	cout<<"\nEnter the value of b : ";
	cin>>b;

    cout << "\nShift Left : " << endl; 
    cout << a<<" << " << b << " = " << (a << b) << endl;
}

void bitwise()
{
	int ch;
	while(1)
	{
		cout<<"\n1. Bitwise AND Operator (&)";
		cout<<"\n2. Bitwise OR Operator (|)";
		cout<<"\n3. Bitwise XOR Operator (^)";
		cout<<"\n4. Bitwise Complement Operator(~)";
		cout<<"\n5. Right Shift Operator (>>)";
		cout<<"\n6. Left Shift Operator (<<)";
		cout<<"\n7. Exit";
		
		cout<<"\n\nEnter your choice : ";
		cin>>ch;
		
		switch(ch)
		{
			case 1:
				Bitwise_AND();
				break;
			case 2:
				Bitwise_OR();
				break;
			case 3:
				Bitwise_XOR();
				break;
			case 4:
				Bitwise_Complement();
				break;
			case 5:
				Right_Shift();
				break;
			case 6:
				Left_Shift();
				break;
			case 7:
				exit(1);
				break;
			default:
				cout<<"\nInvalid Choice!!! Please try again\n";
			}
	}
}

int main()
{
	int ch;
	while(1)
	{
		cout<<"\n\t\t\t\t----------------------MENU DRIVEN PROGRAM------------------------"<<endl;
		cout<<"\n1.Arithmetic Operators";
		cout<<"\n2.Assignment Operators";
		cout<<"\n3.Relational Operators";
		cout<<"\n4.Logical Operators";
		cout<<"\n5.Bitwise Operators";
		cout<<"\n6.Exit";
		
		cout<<"\n\nEnter your choice : ";
		cin>>ch;
		
		switch(ch)
		{
			case 1:
				arithmetic();
				break;
			case 2:
				assignment();
				break;
			case 3:
				relational();
				break;
			case 4:
				logical();
				break;
			case 5:
				bitwise();
				break;
			case 6:
				exit(1);
				break;
			default:
				cout<<"\nInvalid Choice! Please Enter a Valid Choice.\n";
		}
	}

}